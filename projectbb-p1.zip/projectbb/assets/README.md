These assets came from a variety of sources. Their licenses are accompanied with their respective files. 

All of the images including the spaceships, lasers, asteroids, and backgrounds were made by Kenney Vleugels (www.kenney.nl). 
He hosts tons of amazing free assets on his website. Definitely check them out. 

The music was made by sawsquarenoise and was found on freemusicarchive.org.

Fonts were found on Google Fonts.

Sound effects were made by me, Diego, using a program called Bfxr. You can use it to generate and fine tune your own 8-bit sounds. 


Thanks for reading!

-Diego (CodingKaiju.com)